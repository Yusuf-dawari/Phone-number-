package phone2;

import java.util.Scanner;

public class Phone2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your phone number please !");
        String phone = input.nextLine();

        switch (phone.length()) {
            case 10:
                System.out.println("it is valid number");
                break;
            case 0:
                System.out.println("Invalid number");break;
            case 1:
                System.out.println("Invalid number");break;
            case 2:
                System.out.println("Invalid number");break;
            case 3:
                System.out.println("Invalid number");break;
            case 4:
                System.out.println("Invalid number");break;
            case 5:
                System.out.println("Invalid number");break;
            case 6:
                System.out.println("Invalid number");break;
            case 7:
                System.out.println("Invalid number");break;
            case 8:
                System.out.println("Invalid number");break;
            case 9:
                System.out.println("Invalid number");break;

            case 11:
                System.out.println("Invalid number");break;

            case 12:
                System.out.println("Invalid number");break;

            case 13:
                System.out.println("Invalid number");break;

            case 14:
                System.out.println("Invalid number");break;
            case 15:
                System.out.println("Invalid number");break;
            case 16:
                System.out.println("Invalid number");break;

            case 17:
                System.out.println("Invalid number");break;

            case 18:
                System.out.println("Invalid number");break;
                

        }
        if (phone.length()==10){
        if (phone.startsWith("078")){
            System.out.println(" Afghanistan,Etesalat company");
            
        }
        else if (phone.startsWith("079")){
            System.out.println("Afghanistan,Roshan company");
        }
        else if(phone.startsWith("070")){
            System.out.println("Afghanistan,AWCC company");
        }
        else{System.out.println("It does not belong to any company or even does not belong to Afghanistan");
        

    }

}}}
